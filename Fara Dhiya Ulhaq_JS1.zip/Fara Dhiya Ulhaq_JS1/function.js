// Contoh penggunaan function
function tambah(a, b) {
    return a + b;
  }
  
  let hasil = tambah(10, 1);
  console.log("Hasil penambahan: " + hasil);