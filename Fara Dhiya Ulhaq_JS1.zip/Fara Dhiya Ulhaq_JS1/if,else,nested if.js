// Contoh penggunaan if, else, dan nested if
let nilai = 75;

if (nilai >= 80) {
  console.log("Nilai Anda A");
} else if (nilai >= 70) {
  console.log("Nilai Anda B");
} else {
  if (nilai >= 60) {
    console.log("Nilai Anda C");
  } else {
    console.log("Nilai Anda D");
  }
}