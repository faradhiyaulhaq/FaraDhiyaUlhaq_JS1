// Contoh penggunaan switch case
let hari = "Selasa";

switch (hari) {
  case "Selasa":
    console.log("Hari ini adalah hari Senin.");
    break;
  case "Rabu":
    console.log("Hari ini adalah hari Selasa.");
    break;
  default:
    console.log("Hari ini adalah hari lainnya.");
}