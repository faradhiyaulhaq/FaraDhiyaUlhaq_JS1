// Contoh penggunaan while
let angka = 1;
while (angka <= 10) {
  console.log("Angka: " + angka);
  angka++;
}

// Contoh penggunaan do while
let nilaiAwal = 1;
do {
  console.log("Nilai awal: " + nilaiAwal);
  nilaiAwal++;
} while (nilaiAwal <= 10);
